create function fill_rooms()
  returns integer
language plpgsql
as $$
BEGIN
  FOR temp_hotel IN 1..18 LOOP
    FOR persons_count IN 1..5 LOOP
      FOR i IN 1..4 LOOP
        insert into rooms (room, persons, hotel_id) values (i, persons_count, temp_hotel);
      END LOOP;
    END LOOP;
  END LOOP;

  RETURN (SELECT COUNT(id) from rooms);
END;

$$;

alter function fill_rooms()
  owner to postgres;

