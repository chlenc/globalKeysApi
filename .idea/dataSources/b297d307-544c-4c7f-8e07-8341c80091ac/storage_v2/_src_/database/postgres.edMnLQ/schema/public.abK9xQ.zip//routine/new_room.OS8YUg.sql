create function new_room()
  returns trigger
language plpgsql
as $$
BEGIN
  UPDATE rooms SET city_id = (select hotels.city_id from hotels where hotels.id =  new.hotel_id )
  where rooms.id = new.id;
  RETURN NEW;
END;
$$;

alter function new_room()
  owner to postgres;

