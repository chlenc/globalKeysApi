create function update_profile()
  returns trigger
language plpgsql
as $$
BEGIN

      UPDATE users set updated_at = NOW() WHERE id = OLD.user_id;
      RETURN OLD;

    END;
$$;

alter function update_profile()
  owner to postgres;

