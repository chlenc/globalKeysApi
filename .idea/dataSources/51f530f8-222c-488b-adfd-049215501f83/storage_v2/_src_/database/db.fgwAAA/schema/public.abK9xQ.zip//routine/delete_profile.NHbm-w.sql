create function delete_profile()
  returns trigger
language plpgsql
as $$
BEGIN

      DELETE FROM profiles  WHERE user_id = OLD.id;
      RETURN OLD;

    END;
$$;

alter function delete_profile()
  owner to postgres;

