create function new_profile()
  returns trigger
language plpgsql
as $$
BEGIN

      INSERT INTO profiles(user_id) values (new.id);
      RETURN NEW;

    END;
$$;

alter function new_profile()
  owner to postgres;

